/*
  Resume content lives here.
  The chat assistant is constrained to ONLY use this content.
  Replace the placeholder data with your own.
*/

window.RESUME = {
  basics: {
    name: "Alex Taylor",
    headline: "Full‑Stack Developer • React • Node.js • SQL",
    location: "Austin, TX",
    email: "alex.taylor@email.com",
    phone: "+1 (555) 123‑4567",
    website: "https://example.com",
    github: "https://github.com/example",
    linkedin: "https://linkedin.com/in/example"
  },

  about: [
    "Full‑stack developer focused on building reliable web apps with clean UX and strong APIs.",
    "I’ve shipped customer‑facing features end‑to‑end: UI, backend services, data modeling, and observability.",
    "I enjoy collaborating cross‑functionally and turning ambiguous requirements into shipped software."
  ],

  experience: [
    {
      role: "Software Engineer",
      company: "Northwind Labs",
      location: "Remote",
      start: "2023",
      end: "Present",
      highlights: [
        "Built and maintained React + Node.js features used by 20k+ monthly users.",
        "Designed REST APIs and data models in PostgreSQL; improved p95 latency by 35%.",
        "Added structured logging and dashboards (OpenTelemetry + Grafana) to reduce incident triage time."
      ],
      technologies: ["React", "TypeScript", "Node.js", "PostgreSQL", "Redis"]
    },
    {
      role: "Junior Developer",
      company: "Contoso Commerce",
      location: "Austin, TX",
      start: "2021",
      end: "2023",
      highlights: [
        "Implemented payment and checkout enhancements; reduced drop‑off by 8%.",
        "Wrote automated tests and CI checks; increased coverage on key modules.",
        "Partnered with design to refresh UI components and accessibility."
      ],
      technologies: ["JavaScript", "Node.js", "Express", "MongoDB"]
    }
  ],

  projects: [
    {
      name: "IssueFlow",
      description: "Lightweight issue tracker with kanban boards and role‑based access.",
      highlights: [
        "Built a responsive React UI with drag‑and‑drop.",
        "Implemented auth, permissions, and audit logs.",
        "Deployed with CI/CD and environment-based config."
      ],
      technologies: ["React", "TypeScript", "Node.js", "PostgreSQL"],
      links: [{ label: "Repo", url: "https://github.com/example/issueflow" }]
    },
    {
      name: "ShopLens",
      description: "Analytics dashboard for e-commerce performance and cohort retention.",
      highlights: [
        "ETL pipeline to aggregate events into reporting tables.",
        "Interactive charts and filters for product teams."
      ],
      technologies: ["Python", "SQL", "PostgreSQL"],
      links: [{ label: "Demo", url: "https://example.com/shoplens" }]
    }
  ],

  skills: {
    languages: ["TypeScript", "JavaScript", "Python", "SQL"],
    frameworks: ["React", "Node.js", "Express"],
    databases: ["PostgreSQL", "MongoDB", "Redis"],
    tooling: ["Git", "CI/CD", "Docker"],
    practices: ["Testing", "Observability", "Performance", "Accessibility"]
  },

  education: [
    {
      school: "State University",
      degree: "B.S. Computer Science",
      start: "2017",
      end: "2021",
      notes: ["Coursework: data structures, databases, distributed systems"]
    }
  ]
};
