# Digital Resume + Resume-Only Chat Assistant

A tiny static resume website with an in-browser chat assistant that answers questions using **only** the resume content in `resume.js`.

## How to run

### Option A (simplest)
- Open `index.html` in your browser.

### Option B (recommended during editing)
- Use VS Code extension **Live Server** and open `index.html`.

## Customize the resume

Edit `resume.js`:
- `basics`: name, headline, contact links
- `about`: short paragraphs
- `experience`: roles + highlights + technologies
- `projects`: name/description/highlights/tech + links
- `skills`: grouped arrays
- `education`

The page and the assistant both pull from the same data.

## Chat behavior (resume-only)

- The assistant does **not** call external APIs.
- It searches the resume text and responds with the most relevant snippets.
- If it can’t find support in the resume, it answers: “I can’t find that in the resume content provided.”

If you want the assistant to be stricter/looser, tweak thresholds in `answerFromResume()` inside `app.js`.
