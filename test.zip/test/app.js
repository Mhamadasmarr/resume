(() => {
  /**
   * A tiny, local-only resume assistant.
   * It does NOT call external APIs.
   * It answers from resume content only, otherwise says it can't find it.
   */

  const resume = window.RESUME;
  if (!resume) {
    console.error("RESUME data not found. Ensure resume.js is loaded before app.js");
    return;
  }

  // ----------------------------
  // Render resume sections
  // ----------------------------

  const el = (id) => document.getElementById(id);

  function renderBasics() {
    el("name").textContent = resume.basics.name;
    el("headline").textContent = resume.basics.headline;

    const contact = el("contact");
    contact.innerHTML = "";

    const items = [
      resume.basics.location ? { type: "span", text: resume.basics.location } : null,
      resume.basics.email ? { type: "a", text: resume.basics.email, href: `mailto:${resume.basics.email}` } : null,
      resume.basics.phone ? { type: "a", text: resume.basics.phone, href: `tel:${resume.basics.phone.replace(/\s/g, "")}` } : null,
      resume.basics.website ? { type: "a", text: "Website", href: resume.basics.website } : null,
      resume.basics.github ? { type: "a", text: "GitHub", href: resume.basics.github } : null,
      resume.basics.linkedin ? { type: "a", text: "LinkedIn", href: resume.basics.linkedin } : null
    ].filter(Boolean);

    for (const item of items) {
      const node = document.createElement(item.type);
      node.textContent = item.text;
      if (item.href) {
        node.href = item.href;
        node.target = "_blank";
        node.rel = "noreferrer";
      }
      contact.appendChild(node);
    }
  }

  function renderAbout() {
    const root = el("about-content");
    root.innerHTML = "";

    for (const p of resume.about) {
      const para = document.createElement("p");
      para.textContent = p;
      root.appendChild(para);
    }
  }

  function renderExperience() {
    const root = el("experience-content");
    root.innerHTML = "";

    const ul = document.createElement("ul");
    ul.className = "list";

    for (const job of resume.experience) {
      const li = document.createElement("li");
      li.className = "item";

      const top = document.createElement("div");
      top.className = "top";

      const left = document.createElement("div");
      left.innerHTML = `<div class="title">${escapeHtml(job.role)} <span class="where">@ ${escapeHtml(job.company)} • ${escapeHtml(job.location || "")}</span></div>`;

      const right = document.createElement("div");
      right.className = "time";
      right.textContent = `${job.start} — ${job.end}`;

      top.appendChild(left);
      top.appendChild(right);

      const bullets = document.createElement("ul");
      for (const h of job.highlights || []) {
        const b = document.createElement("li");
        b.textContent = h;
        bullets.appendChild(b);
      }

      const pills = renderPills(job.technologies);

      li.appendChild(top);
      li.appendChild(bullets);
      if (pills) li.appendChild(pills);
      ul.appendChild(li);
    }

    root.appendChild(ul);
  }

  function renderProjects() {
    const root = el("projects-content");
    root.innerHTML = "";

    const ul = document.createElement("ul");
    ul.className = "list";

    for (const proj of resume.projects) {
      const li = document.createElement("li");
      li.className = "item";

      const top = document.createElement("div");
      top.className = "top";

      const title = document.createElement("div");
      title.innerHTML = `<div class="title">${escapeHtml(proj.name)}</div><div class="where">${escapeHtml(proj.description || "")}</div>`;
      top.appendChild(title);

      li.appendChild(top);

      if (proj.highlights?.length) {
        const bullets = document.createElement("ul");
        for (const h of proj.highlights) {
          const b = document.createElement("li");
          b.textContent = h;
          bullets.appendChild(b);
        }
        li.appendChild(bullets);
      }

      const pills = renderPills(proj.technologies);
      if (pills) li.appendChild(pills);

      if (proj.links?.length) {
        const links = document.createElement("div");
        links.className = "pills";
        for (const l of proj.links) {
          const a = document.createElement("a");
          a.className = "pill";
          a.href = l.url;
          a.target = "_blank";
          a.rel = "noreferrer";
          a.textContent = l.label;
          links.appendChild(a);
        }
        li.appendChild(links);
      }

      ul.appendChild(li);
    }

    root.appendChild(ul);
  }

  function renderSkills() {
    const root = el("skills-content");
    root.innerHTML = "";

    const groups = resume.skills;
    const entries = Object.entries(groups);

    for (const [group, values] of entries) {
      const wrap = document.createElement("div");
      wrap.className = "item";
      const h = document.createElement("div");
      h.className = "title";
      h.textContent = titleCase(group);
      wrap.appendChild(h);

      const pills = renderPills(values);
      if (pills) wrap.appendChild(pills);
      root.appendChild(wrap);
    }
  }

  function renderEducation() {
    const root = el("education-content");
    root.innerHTML = "";

    const ul = document.createElement("ul");
    ul.className = "list";

    for (const edu of resume.education) {
      const li = document.createElement("li");
      li.className = "item";

      const top = document.createElement("div");
      top.className = "top";

      const left = document.createElement("div");
      left.innerHTML = `<div class="title">${escapeHtml(edu.degree)}</div><div class="where">${escapeHtml(edu.school)}</div>`;

      const right = document.createElement("div");
      right.className = "time";
      right.textContent = `${edu.start} — ${edu.end}`;

      top.appendChild(left);
      top.appendChild(right);

      li.appendChild(top);

      if (edu.notes?.length) {
        const notes = document.createElement("ul");
        for (const n of edu.notes) {
          const b = document.createElement("li");
          b.textContent = n;
          notes.appendChild(b);
        }
        li.appendChild(notes);
      }

      ul.appendChild(li);
    }

    root.appendChild(ul);
  }

  function renderPills(values) {
    if (!values?.length) return null;
    const pills = document.createElement("div");
    pills.className = "pills";
    for (const v of values) {
      const p = document.createElement("span");
      p.className = "pill";
      p.textContent = v;
      pills.appendChild(p);
    }
    return pills;
  }

  function titleCase(s) {
    return String(s)
      .replace(/[-_]/g, " ")
      .replace(/\b\w/g, (m) => m.toUpperCase());
  }

  function escapeHtml(str) {
    return String(str)
      .replaceAll("&", "&amp;")
      .replaceAll("<", "&lt;")
      .replaceAll(">", "&gt;")
      .replaceAll('"', "&quot;")
      .replaceAll("'", "&#039;");
  }

  // ----------------------------
  // Chat assistant (resume-only)
  // ----------------------------

  const chatBody = el("chatBody");
  const chatForm = el("chatForm");
  const chatInput = el("chatInput");

  function addMsg(role, text, sources = []) {
    const row = document.createElement("div");
    row.className = `msg ${role}`;

    const avatar = document.createElement("div");
    avatar.className = "avatar";
    avatar.textContent = role === "user" ? "You" : "AI";

    const bubble = document.createElement("div");
    bubble.className = "bubble";

    const content = document.createElement("div");
    content.textContent = text;
    bubble.appendChild(content);

    if (sources.length) {
      const s = document.createElement("div");
      s.className = "sources";
      s.textContent = `Sources: ${sources.join(" • ")}`;
      bubble.appendChild(s);
    }

    row.appendChild(avatar);
    row.appendChild(bubble);
    chatBody.appendChild(row);
    chatBody.scrollTop = chatBody.scrollHeight;
  }

  function normalize(t) {
    return String(t).toLowerCase();
  }

  function tokenize(text) {
    return normalize(text)
      .replace(/[^a-z0-9\s+.#-]/g, " ")
      .split(/\s+/)
      .filter(Boolean);
  }

  function buildChunks(resume) {
    const chunks = [];

    const add = (section, text) => {
      const cleaned = String(text || "").trim();
      if (!cleaned) return;
      chunks.push({ section, text: cleaned, tokens: tokenize(cleaned) });
    };

    add("Basics", `${resume.basics.name} — ${resume.basics.headline}`);
    add("Basics", `Location: ${resume.basics.location}`);

    for (const p of resume.about || []) add("About", p);

    for (const job of resume.experience || []) {
      add(
        "Experience",
        `${job.role} at ${job.company} (${job.location || ""}), ${job.start} to ${job.end}. Technologies: ${(job.technologies || []).join(", ")}.`
      );
      for (const h of job.highlights || []) add("Experience", h);
    }

    for (const proj of resume.projects || []) {
      add("Projects", `${proj.name}: ${proj.description || ""}. Technologies: ${(proj.technologies || []).join(", ")}.`);
      for (const h of proj.highlights || []) add("Projects", h);
      for (const l of proj.links || []) add("Projects", `${proj.name} link: ${l.label} (${l.url})`);
    }

    const skills = resume.skills || {};
    for (const [k, vals] of Object.entries(skills)) {
      add("Skills", `${titleCase(k)}: ${(vals || []).join(", ")}`);
    }

    for (const edu of resume.education || []) {
      add("Education", `${edu.degree}, ${edu.school} (${edu.start}–${edu.end})`);
      for (const n of edu.notes || []) add("Education", n);
    }

    return chunks;
  }

  const chunks = buildChunks(resume);

  function scoreChunk(questionTokens, chunkTokens) {
    if (!questionTokens.length || !chunkTokens.length) return 0;

    const chunkSet = new Set(chunkTokens);
    let hits = 0;

    for (const t of questionTokens) {
      if (chunkSet.has(t)) hits += 1;
    }

    // small bias towards longer overlaps
    const overlap = hits / Math.sqrt(questionTokens.length * chunkTokens.length);
    return overlap;
  }

  function answerFromResume(question) {
    const qTokens = tokenize(question);

    // Guardrails: if question is too short, ask user to clarify.
    if (qTokens.length < 2) {
      return {
        text: "Can you add a bit more detail to the question so I can match it to the resume?",
        sources: []
      };
    }

    const scored = chunks
      .map((c) => ({ ...c, score: scoreChunk(qTokens, c.tokens) }))
      .sort((a, b) => b.score - a.score);

    const top = scored.slice(0, 6).filter((x) => x.score > 0);

    if (!top.length) {
      return {
        text: "I can’t find that in the resume content provided.",
        sources: []
      };
    }

    // Compose an answer by quoting/paraphrasing ONLY from the chunks.
    // We keep it conservative: show the most relevant sentences as the answer.
    const picked = top.slice(0, 3);
    const sources = Array.from(new Set(picked.map((p) => p.section)));

    // If user asked for a summary, provide a short synthesis by concatenating chunks.
    const q = normalize(question);
    const wantsSummary = /(summarize|summary|overview|tell me about|what is|describe)/.test(q);

    if (wantsSummary) {
      return {
        text: picked.map((p) => p.text).join(" "),
        sources
      };
    }

    // For most questions, return the best matching chunk; include 1-2 supporting chunks.
    const primary = picked[0].text;
    const support = picked.slice(1).map((p) => p.text);

    return {
      text: support.length ? `${primary} ${support.join(" ")}` : primary,
      sources
    };
  }

  function bootChat() {
    addMsg(
      "assistant",
      "Hi! Ask me anything about this resume. I’ll answer using only what’s on the page.",
      []
    );
  }

  chatForm.addEventListener("submit", (e) => {
    e.preventDefault();

    const q = chatInput.value.trim();
    if (!q) return;

    addMsg("user", q);
    chatInput.value = "";

    const { text, sources } = answerFromResume(q);
    addMsg("assistant", text, sources);
  });

  document.querySelectorAll(".chip").forEach((btn) => {
    btn.addEventListener("click", () => {
      const q = btn.getAttribute("data-q");
      if (!q) return;
      chatInput.value = q;
      chatForm.requestSubmit();
    });
  });

  // Render all
  renderBasics();
  renderAbout();
  renderExperience();
  renderProjects();
  renderSkills();
  renderEducation();
  bootChat();
})();
